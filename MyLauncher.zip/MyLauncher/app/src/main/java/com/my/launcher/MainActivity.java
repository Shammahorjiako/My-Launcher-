package com.my.launcher;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  WebView w;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    w.setBackgroundColor(Color.BLACK);
    w.addJavascriptInterface(new Br(), "Android");
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
  @Override public void onBackPressed() { w.evaluateJavascript("opn(false)", null); }
  class Br {
    @JavascriptInterface public String getApps() {
      try {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> l = pm.queryIntentActivities(i, 0);
        Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
        JSONArray a = new JSONArray();
        for (ResolveInfo r : l) {
          if (r.activityInfo.packageName.equals(getPackageName())) continue;
          JSONObject o = new JSONObject();
          o.put("n", r.loadLabel(pm).toString());
          o.put("p", r.activityInfo.packageName);
          o.put("i", icon(r.loadIcon(pm)));
          a.put(o);
        }
        return a.toString();
      } catch (Exception e) { return "[]"; }
    }
    @JavascriptInterface public void launch(String p) {
      Intent i = getPackageManager().getLaunchIntentForPackage(p);
      if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
    }
  }
  String icon(Drawable d) {
    Bitmap bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(bm);
    d.setBounds(0, 0, 96, 96);
    d.draw(c);
    ByteArrayOutputStream o = new ByteArrayOutputStream();
    bm.compress(Bitmap.CompressFormat.PNG, 100, o);
    return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
  }
}
